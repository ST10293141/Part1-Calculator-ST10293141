package com.example.part1_calculator_st10293141

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

private lateinit var display_result : TextView
private lateinit var editfirst : EditText
private lateinit var editsecond : EditText
private lateinit var add : Button
private lateinit var subtract : Button
private lateinit var multiply : Button
private lateinit var divide : Button

@SuppressLint("MissingInflatedId")
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display_result = findViewById(R.id.display_result)
        editfirst = findViewById(R.id.edit_first)
        editsecond = findViewById(R.id.edit_second)
        add = findViewById(R.id.add)
        subtract = findViewById(R.id.subtract)
        multiply = findViewById(R.id.multiply)
        divide = findViewById(R.id.divide)

        add.setOnClickListener {
            val res1 = editfirst.text.toString().toInt()
            val res2 = editsecond.text.toString().toInt()
            addition(res1, res2)
        }
        subtract.setOnClickListener {
            val res1 = editfirst.text.toString().toInt()
            val res2 = editsecond.text.toString().toInt()
            subtraction(res1, res2)
        }
        multiply.setOnClickListener {
            val res1 = editfirst.text.toString().toInt()
            val res2 = editsecond.text.toString().toInt()
            multiplication(res1, res2)
        }
        divide.setOnClickListener {
            val res1 = editfirst.text.toString().toInt()
            val res2 = editsecond.text.toString().toInt()
            division(res1, res2)
        }
    }

    private fun addition(res1: Int, res2: Int)
    {
        val result = res1 + res2
        display_result.text = result.toString()
    }
    private fun subtraction(res1: Int, res2: Int)
    {
        val result = res1 - res2
        display_result.text = result.toString()
    }
    private fun multiplication(res1: Int, res2: Int)
    {
        val result = res1 * res2
        display_result.text = result.toString()
    }
    private fun division(res1: Int, res2: Int)
    {
        val result = res1 / res2
        display_result.text = result.toString()
    }
}